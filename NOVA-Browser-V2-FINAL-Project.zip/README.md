# NOVA Browser Final

A clean Android WebView browser focused on DuckDuckGo search, practical navigation,
real Android downloads, voice input, text-to-speech and a foundation for future
NOVA AI features.

## Build
The repository includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It builds `assembleDebug` and uploads the APK as an artifact.

## Current real features
- DuckDuckGo search/address bar
- Back, forward, reload, home
- Real WebView browsing
- WebView download detection using Android DownloadManager
- Download notifications handled by Android
- File chooser for web uploads
- Voice search using Android SpeechRecognizer when supported
- NOVA text-to-speech
- Desktop-mode toggle
- JavaScript toggle
- Clear browser data
- Basic tab creation/switching through the tab button
- Share current URL
- Error handling and offline page fallback

## Important limitations
Segmented/parallel downloading is only safe when the remote server supports HTTP
range requests. This version does not pretend to bypass DRM, authentication,
paywalls or access restrictions.

A future AI provider can be connected through the NOVA AI button; no private API key
is hard-coded in this project.

## Release
Configure signing secrets before publishing an AAB to Google Play.
