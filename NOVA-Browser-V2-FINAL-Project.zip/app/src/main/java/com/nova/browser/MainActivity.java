package com.nova.browser;

import android.Manifest;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends android.app.Activity {

    private static final int REQ_AUDIO = 401;
    private static final int REQ_NOTIFICATIONS = 402;

    private LinearLayout root;
    private EditText address;
    private WebView webView;
    private TextToSpeech tts;
    private SpeechRecognizer speechRecognizer;
    private boolean desktopMode = false;
    private boolean javascriptEnabled = true;
    private int tabCount = 1;

    private final String HOME = "https://duckduckgo.com/";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        buildUi();
        setupSpeech();
        setupTts();

        if (state == null) {
            loadUrl(HOME);
        } else {
            webView.restoreState(state);
        }

        requestRuntimePermissions();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF101116);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(8), dp(8), dp(4));

        address = new EditText(this);
        address.setSingleLine(true);
        address.setHint("Search or enter address");
        address.setTextColor(0xFFFFFFFF);
        address.setHintTextColor(0xFF9FA2AE);
        address.setTextSize(15);
        address.setBackgroundColor(0xFF191B23);
        address.setPadding(dp(12), 0, dp(8), 0);
        address.setOnEditorActionListener((v, actionId, event) -> {
            navigateFromAddress();
            return true;
        });

        Button go = button("GO");
        go.setOnClickListener(v -> navigateFromAddress());

        Button voice = button("🎙");
        voice.setOnClickListener(v -> startVoice());

        top.addView(address, new LinearLayout.LayoutParams(0, dp(48), 1));
        top.addView(go, new LinearLayout.LayoutParams(dp(52), dp(48)));
        top.addView(voice, new LinearLayout.LayoutParams(dp(52), dp(48)));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER);
        toolbar.setPadding(dp(4), 0, dp(4), dp(4));

        Button back = button("‹");
        back.setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });

        Button forward = button("›");
        forward.setOnClickListener(v -> { if (webView.canGoForward()) webView.goForward(); });

        Button reload = button("↻");
        reload.setOnClickListener(v -> webView.reload());

        Button home = button("⌂");
        home.setOnClickListener(v -> loadUrl(HOME));

        Button tabs = button("Tabs 1");
        tabs.setOnClickListener(v -> {
            tabCount++;
            tabs.setText("Tabs " + tabCount);
            Toast.makeText(this, "New tab requested. Current page kept active.", Toast.LENGTH_SHORT).show();
        });

        Button menu = button("☰");
        menu.setOnClickListener(v -> showMenu());

        toolbar.addView(back, weightParams());
        toolbar.addView(forward, weightParams());
        toolbar.addView(reload, weightParams());
        toolbar.addView(home, weightParams());
        toolbar.addView(tabs, weightParams());
        toolbar.addView(menu, weightParams());

        webView = new WebView(this);
        configureWebView();

        root.addView(top);
        root.addView(toolbar);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(javascriptEnabled);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    String scheme = request.getUrl().getScheme();
                    if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                        return false;
                    }
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                address.setText(url);
                address.setSelection(address.length());
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            "Page could not be loaded.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                startDownload(url, userAgent, contentDisposition, mimeType);
            }
        });
    }

    private void startDownload(String url, String userAgent, String contentDisposition,
                               String mimeType) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mimeType);
            request.addRequestHeader("User-Agent", userAgent);
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);
            request.setTitle(downloadTitle(contentDisposition, url));
            request.setDescription("NOVA Browser download");
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    downloadFileName(contentDisposition, url));

            DownloadManager dm =
                    (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Download failed to start", Toast.LENGTH_LONG).show();
        }
    }

    private String downloadTitle(String cd, String url) {
        String name = downloadFileName(cd, url);
        return name.isEmpty() ? "NOVA download" : name;
    }

    private String downloadFileName(String cd, String url) {
        if (cd != null) {
            String marker = "filename=";
            int p = cd.toLowerCase(Locale.US).indexOf(marker);
            if (p >= 0) {
                String n = cd.substring(p + marker.length()).trim();
                n = n.replace("\"", "").replace("'", "");
                if (!n.isEmpty()) return n;
            }
        }
        try {
            String path = Uri.parse(url).getLastPathSegment();
            if (path != null && !path.isEmpty() && path.length() < 180) return path;
        } catch (Exception ignored) {}
        return "NOVA_download";
    }

    private void navigateFromAddress() {
        String raw = address.getText().toString().trim();
        if (raw.isEmpty()) return;

        if (raw.matches("(?i)^https?://.*")) {
            loadUrl(raw);
        } else if (raw.contains(".") && !raw.contains(" ")) {
            loadUrl("https://" + raw);
        } else {
            loadUrl("https://duckduckgo.com/?q=" + Uri.encode(raw));
        }
    }

    private void loadUrl(String url) {
        if (webView != null) webView.loadUrl(url);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(12);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams weightParams() {
        return new LinearLayout.LayoutParams(0, dp(44), 1);
    }

    private void showMenu() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(8), dp(16), dp(8));

        Button voice = button("NOVA Voice");
        voice.setOnClickListener(v -> startVoice());

        Button speak = button("NOVA Speak");
        speak.setOnClickListener(v -> {
            String text = webView.getTitle();
            if (text == null || text.isEmpty()) text = "NOVA Browser is ready.";
            speak(text);
        });

        Button desktop = button(desktopMode ? "Desktop mode: ON" : "Desktop mode: OFF");
        desktop.setOnClickListener(v -> {
            desktopMode = !desktopMode;
            webView.getSettings().setUserAgentString(
                    desktopMode
                            ? "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
                            : null);
            webView.reload();
        });

        Button js = button(javascriptEnabled ? "JavaScript: ON" : "JavaScript: OFF");
        js.setOnClickListener(v -> {
            javascriptEnabled = !javascriptEnabled;
            webView.getSettings().setJavaScriptEnabled(javascriptEnabled);
            webView.reload();
        });

        Button share = button("Share current page");
        share.setOnClickListener(v -> shareCurrentPage());

        Button clear = button("Clear browser data");
        clear.setOnClickListener(v -> {
            webView.clearHistory();
            webView.clearCache(true);
            CookieManager.getInstance().removeAllCookies(null);
            Toast.makeText(this, "Browser data cleared", Toast.LENGTH_SHORT).show();
        });

        panel.addView(voice);
        panel.addView(speak);
        panel.addView(desktop);
        panel.addView(js);
        panel.addView(share);
        panel.addView(clear);

        setContentView(panel);
    }

    private void shareCurrentPage() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, webView.getUrl());
        startActivity(Intent.createChooser(i, "Share page"));
    }

    private void setupSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> list =
                        results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) {
                    address.setText(list.get(0));
                    navigateFromAddress();
                }
            }

            @Override
            public void onError(int error) {
                Toast.makeText(MainActivity.this,
                        "Voice recognition unavailable", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }

        if (speechRecognizer == null) {
            Toast.makeText(this, "Speech recognition is unavailable on this device.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        speechRecognizer.startListening(intent);
    }

    private void setupTts() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.getDefault());
            }
        });
    }

    private void speak(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "NOVA");
        }
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIFICATIONS);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        webView.saveState(out);
        super.onSaveInstanceState(out);
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
